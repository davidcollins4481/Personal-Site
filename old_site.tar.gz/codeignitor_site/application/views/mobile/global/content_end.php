        </div>
        <footer>
            <p>Copyright &copy; CSS3_photo_two | <a href="http://www.css3templates.co.uk">Credit</a></p>
        </footer>
    </div>
    <p>&nbsp;</p>
    <!-- javascript at the bottom for fast page loading -->
    <script type="text/javascript" src="/js/jquery.js"></script>
    <script type="text/javascript" src="/js/jquery.easing-sooper.js"></script>
    <script type="text/javascript" src="/js/jquery.sooperfish.js"></script>
    <script type="text/javascript" src="/js/jquery.cookie.js"></script>