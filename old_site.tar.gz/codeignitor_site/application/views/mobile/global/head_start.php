<head>
    <title>FranticPedantic</title>
    <link rel="stylesheet" href="/themes/frantic-pedantic-mobile-theme.min.css" />
    <link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile.structure-1.3.0-rc.1.min.css" />
    <script src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
    <script src="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.js"></script>
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="/css/mobile/style.css" media="all">
    <script type="text/javascript" src="/js/modernizr-1.5.min.js"></script>
    <script type="text/javascript" src="/js/sprintf-0.6.js"></script>
