<nav>
    <ul class="sf-menu" id="nav" data-role="listview" data-inset="true" data-filter="false">
        <li><a href="/main/playground">Playground</a></li>
        <li><a href="/main/contact">Contact Me</a></li>
    </ul>
</nav>