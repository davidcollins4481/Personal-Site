    <div id="main">
        <header>
            <div id="logo">
                <div id="logo_text">
                    <!-- class="logo_colour", allows you to change the colour of the text -->
                    <h1><a href="/">Frantic<span class="logo_colour">Pedantic</span></a></h1>
                    <h2>Dad. Developer.</h2>
                </div>
            </div>
        </header>
    
        <div id="site_content">
            <!--
            <div class="gallery">
                <ul class="images">
                    <li class="show"><img width="950" height="300" src="/images/1.jpg" alt="photo_one"></li>
                    <li><img width="950" height="300" src="/images/2.jpg" alt="photo_two"></li>
                    <li><img width="950" height="300" src="/images/3.jpg" alt="photo_three"></li>
                </ul>
            </div>
            -->
            <div id="sidebar_container">
                <!--
                <div class="sidebar"></div>
                
                <div class="sidebar">
                    <h3>Useful Links</h3>
                    <ul>
                        <li><a href="#">First Link</a></li>
                        <li><a href="#">Another Link</a></li>
                        <li><a href="#">And Another</a></li>
                        <li><a href="#">Last One</a></li>
                    </ul>
                </div>
                -->
            </div>