<?php $this->load->view("global/html_start.php");?>
<?php $this->load->view("global/head_start.php");?>
<?php $this->load->view("global/head_end.php");?>
<?php $this->load->view("global/body_start.php");?>
<?php $this->load->view("global/content_start.php");?>

<div id="nav-container">
    <?php $this->load->view("global/nav.php");?>
</div>

<?php $this->load->view("global/content_end.php");?>
<?php $this->load->view("global/body_end.php");?>
<?php $this->load->view("global/html_end.php");?>
