<?php
    $this->load->helper('html');
    echo doctype('html5')
?>

