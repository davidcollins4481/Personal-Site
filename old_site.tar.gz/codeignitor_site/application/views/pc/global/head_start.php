<head>
    <title>FranticPedantic</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="/css/style.css">
    <script type="text/javascript" src="/js/jquery.js"></script>
    <script type="text/javascript" src="/js/jquery.easing-sooper.js"></script>
    <script type="text/javascript" src="/js/jquery.sooperfish.js"></script>
    <script type="text/javascript" src="/js/jquery.cookie.js"></script>
    <script type="text/javascript" src="/js/modernizr-1.5.min.js"></script>
