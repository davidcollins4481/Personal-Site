<nav>
    <ul class="sf-menu" id="nav">
        <li><a href="/">Home</a></li>
        <li><a href="/main/playground">Playground</a></li>
        <li><a href="/main/contact">Contact Me</a></li>
        <li><a href="/blog">Blog</a></li>
    </ul>
</nav>
