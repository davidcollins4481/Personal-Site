        </div>
        <footer>
            <p>Copyright &copy; CSS3_photo_two | <a href="http://www.css3templates.co.uk">design from css3templates.co.uk</a></p>
        </footer>
    </div>
    <p>&nbsp;</p>