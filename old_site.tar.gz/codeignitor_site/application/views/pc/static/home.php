<?php $this->load->view("global/html_start.php");?>
<?php $this->load->view("global/head_start.php");?>
<?php $this->load->view("global/head_end.php");?>
<?php $this->load->view("global/content_start.php");?>

            <div class="content" style="width:100%">
                <div style="float:left; width: 600px;">
                    <!--<p>This is my site. There are many like it, but this one is mine. This is m</p>-->
                    <p>
                        Hello. This is my personal site to play around on, blog (when I get that set up), put on business cards, whatever. Please don't mistake
                        my casual tone with a lack of professionalism. As much as I want to create a place to point others to
                        for professional purposes, I also want a place to feel comfortable exploring tech topics and communicating
                        with others. I'm just getting this site set up so I imagine very people even know it exists. Probably a good thing right now I guess :)
                    </p>
                </div>
            </div>

<?php $this->load->view("global/content_end.php");?>
<?php $this->load->view("global/body_end.php");?>
<?php $this->load->view("global/html_end.php");?>
