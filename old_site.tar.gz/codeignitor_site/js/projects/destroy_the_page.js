$(document).ready(function() {

    if ($('#ship').length) {
        var ship = new Ship({
            node: $('#ship')[0]
        });
    }

});