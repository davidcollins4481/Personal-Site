<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$autoload['libraries'] = array('Mustache_spark');
