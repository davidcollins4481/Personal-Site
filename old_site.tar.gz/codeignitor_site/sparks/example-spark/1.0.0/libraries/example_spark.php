<?php

class Example_spark
{
    public function printHello()
    {
      echo "Hello from the example spark!";
    }
}
